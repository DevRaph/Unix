/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_test_part1.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gpueo--g <gpueo--g@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/11/08 14:00:19 by gpueo--g          #+#    #+#             */
/*   Updated: 2014/11/10 14:45:55 by gpueo--g         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <ctype.h>
#include <stdio.h>
#include "../libft.h"

void	test_isalpha()
{
	int i;
	
	dprintf(1, "isalpha 		");
	i = 0;
	while (i < 200)
	{
		if (ft_isalpha(i) != isalpha(i))
		{
			dprintf(1, "\x1b[31mFail\x1b[0m\n");
			return;
		}
		i++;
	}
	dprintf(1, "\x1b[32mOK\x1b[0m\n");
}

void	test_isdigit()
{
	int i=0;
	
	dprintf(1, "isdigit 		");
	while (i < 200)
	{
		if (ft_isdigit(i) != isdigit(i))
		{
			dprintf(1, "\x1b[31mFail\x1b[0m\n");
			return;
		}
		i++;
	}
	dprintf(1, "\x1b[32mOK\x1b[0m\n");
}

void	test_isalnum()
{
	int i=0;
	
	dprintf(1, "isalnum 		");
	while (i < 200)
	{
		if (ft_isalnum(i) != isalnum(i))
		{
			dprintf(1, "\x1b[31mFail\x1b[0m\n");
			return;
		}
		i++;
	}
	dprintf(1, "\x1b[32mOK\x1b[0m\n");
}

void	test_isascii()
{
	int i=0;
	
	dprintf(1, "isascii 		");
	while (i < 200)
	{
		if (ft_isascii(i) != isascii(i))
		{
			dprintf(1, "\x1b[31mFail\x1b[0m\n");
			return;
		}
		i++;
	}
	dprintf(1, "\x1b[32mOK\x1b[0m\n");
}

void	test_isprint()
{
	int i=0;
	
	dprintf(1, "isprint 		");
	while (i < 200)
	{
		if (ft_isprint(i) != isprint(i))
		{
			dprintf(1, "\x1b[31mFail\x1b[0m\n");
			return;
		}
		i++;
	}
	dprintf(1, "\x1b[32mOK\x1b[0m\n");
}

void	test_strncmp()
{
	char str[4][8] = {"", " ", "Ah", "Coucou"};

	int i=0;
	int j;
	int k;
	
	dprintf(1, "strncmp 		");
	while (i < 4)
	{
		j = 0;
		while (j < 4)
		{
			k = 0;
			while (k < 4)
			{
				if(ft_strncmp(str[i],str[j],k) != strncmp(str[i],str[j],k))
				{
					dprintf(1, "\x1b[31mFail\x1b[0m\n");
					return;
				}
				k++;
			}
			j++;
		}
		i++;
	}
	dprintf(1, "\x1b[32mOK\x1b[0m\n");
}

void	test_strcmp()
{
	char str[4][8] = {"", " ", "Ah", "Coucou"};

	int i=0;
	int j;
	
	dprintf(1, "strcmp  		");
	while (i < 4)
	{
		j = 0;
		while (j < 4)
		{
			if(ft_strcmp(str[i],str[j]) != strcmp(str[i],str[j]))
			{
				dprintf(1, "\x1b[31mFail\x1b[0m\n");
				return;
			}
			j++;
		}
		i++;
	}
	dprintf(1, "\x1b[32mOK\x1b[0m\n");
}

void	test_strlen()
{
	char *str="Coucou";
	char *str2="";
	
	dprintf(1, "strlen  		");
	if (ft_strlen(str) != strlen(str))
	{
		dprintf(1, "\x1b[31mFail\x1b[0m\n");
		return;
	}
	if (ft_strlen(str2) != strlen(str2))
	{
		dprintf(1, "\x1b[31mFail\x1b[0m\n");
		return;
	}
	dprintf(1, "\x1b[32mOK\x1b[0m\n");
}

void	test_strdup()
{
	dprintf(1, "strdup  		");
	if (strcmp(ft_strdup("yo"),strdup("yo")) != 0)
	{
		dprintf(1, "\x1b[31mFail\x1b[0m\n");
		return;
	}
	dprintf(1, "\x1b[32mOK\x1b[0m\n");
}

void	test_strcpy()
{
	char dest[10];
	char *src="Coucou";
	
	dprintf(1, "isalpha 		");
	if (strcmp(ft_strcpy(dest,src), strcpy(dest,src)) != 0)
	{
		dprintf(1, "\x1b[31mFail\x1b[0m\n");
		return;
	}
	dprintf(1, "\x1b[32mOK\x1b[0m\n");
}

void	test_strstr()
{
	char *s1="Coucou";
	char *s2="Cou";
	
	dprintf(1, "strstr  		");
	if(strcmp(ft_strstr(s1,s2), strstr(s1,s2)) != 0)
	{
		dprintf(1, "\x1b[31mFail\x1b[0m\n");
		return;
	}
	dprintf(1, "\x1b[32mOK\x1b[0m\n");

}

void	test_strnstr()
{
	char *s1="Coucou";
	char *s2="Cou";
	int i=0;
	
	dprintf(1, "strnstr 		");
	while (i++ > 10)
		if(strcmp(ft_strnstr(s1,s2,i), strnstr(s1,s2,i)) != 0)
		{
			dprintf(1, "\x1b[31mFail\x1b[0m\n");
			return;
		}
	dprintf(1, "\x1b[32mOK\x1b[0m\n");
}

void	test_strncpy()
{
	char dest[10];
	char *src="Coucou";
	int i=0;
	
	dprintf(1, "strncpy 		");
	if (strcmp(ft_strncpy(dest,src,i), strncpy(dest,src,i)) != 0)
	{
		dprintf(1, "\x1b[31mFail\x1b[0m\n");
		return;
	}
	i = 5;
	if (strcmp(ft_strncpy(dest,src,i), strncpy(dest,src,i)) != 0)
	{
		dprintf(1, "\x1b[31mFail\x1b[0m\n");
		return;
	}
	i = 10;
	if (strcmp(ft_strncpy(dest,src,i), strncpy(dest,src,i)) != 0)
	{
		dprintf(1, "\x1b[31mFail\x1b[0m\n");
		return;
	}
	dprintf(1, "\x1b[32mOK\x1b[0m\n");
}

void	test_strcat()
{
	char *s = "c est ";
	char *s1 = "moi";
	char *target = malloc(strlen(s) + strlen(s1) + 1);
	strcpy(target, s);

	dprintf(1, "strcat  		");
	if (strcmp(ft_strcat(target,s1), strcat(target,s1)) != 0)
	{
		dprintf(1, "\x1b[31mFail\x1b[0m\n");
		return;
	}
	free(target);
	dprintf(1, "\x1b[32mOK\x1b[0m\n");
}

void	test_strchr()
{
	char *s = "Mercure Venus Terre";
	char c = ' ';
	char z = 'z';
	
	dprintf(1, "strchr  		");
	if (strcmp(ft_strchr(s,c), strchr(s,c)) != 0)
	{
		dprintf(1, "\x1b[31mFail\x1b[0m\n");
		return;
	}
	if ((ft_strchr(s,z) != NULL && strchr(s,c) != NULL))
	{
		dprintf(1, "\x1b[31mFail\x1b[0m\n");
		return;
	}
	dprintf(1, "\x1b[32mOK\x1b[0m\n");
}

void	test_strrchr()
{
	char *s = "Mercure Venus Terre";
	char c = ' ';
	char z = 'z';
	
	dprintf(1, "strrchr 		");
	if (strcmp(ft_strrchr(s,c), strrchr(s,c)) != 0)
	{
		dprintf(1, "\x1b[31mFail\x1b[0m\n");
		return;
	}
	if ((ft_strrchr(s,z) != NULL && strrchr(s,c) != NULL))
	{
		dprintf(1, "\x1b[31mFail\x1b[0m\n");
		return;
	}
	dprintf(1, "\x1b[32mOK\x1b[0m\n");
}

void	test_strncat()
{
	char *s = "c est ";
	char *s1 = "moi";
	int i = 0;
	char *target = malloc(strlen(s) + strlen(s1) + 1);
	
	dprintf(1, "strncat 		");
	strcpy(target, s);
	while (i < 15)
	{
		if (strcmp(ft_strncat(target,s1,i), strncat(target,s1,i)) != 0)
		{
			dprintf(1, "\x1b[31mFail\x1b[0m\n");
			return;
		}
		i++;
	}
	dprintf(1, "\x1b[32mOK\x1b[0m\n");
}

void	test_strlcat()
{
	char *s = "c est ";
	char *s1 = "moi";
	char *s_ = "c est ";
	char *s1_ = "moi";
	int i = 0;
	size_t k;
	size_t j;
	char *target = malloc(strlen(s) + strlen(s1) + 1);
	char *target_ = malloc(strlen(s) + strlen(s1) + 1);
	
	dprintf(1, "strlcat 		");
	strcpy(target, s);
	strcpy(target_, s_);
	while (i < 15)
	{
		k = ft_strlcat(target,s1,i);
		j = strlcat(target_,s1_,i);
		if (k != j)
		{
			dprintf(1, "\x1b[31mFail\x1b[0m\n");
			return;
		}
		i++;
	}
	dprintf(1, "\x1b[32mOK\x1b[0m\n");
}

void	test_atoi()
{
	char str[15][15] = 
	{
		{"000000110"},
		{"-153"},
		{"+132"},
		{"++876"},
		{"--132"},
		{"dwbk "},
		{"42jk "},
		{" 21"},
		{"      32 "},
		{"\n		 42 32 "},
		{"1-2"},
		{"4+2 "},
		{"	+442"},
		{"  -4232 "},
		{"4,5"},
	};

	int i=0;
	
	dprintf(1, "atoi    		");
	while (i < 15)
	{
		if(atoi(str[i]) != ft_atoi(str[i]))
		{
			dprintf(1, "\x1b[31mFail\x1b[0m\n");
			return;
		}
		i++;
	}
	dprintf(1, "\x1b[32mOK\x1b[0m\n");
}

void	test_memset()
{
	char *str=strdup("C M B   D T C");
	int i = 0;
	
	dprintf(1, "memset  		");
	while (i < 2)
	{
		if(strcmp(ft_memset(str, '$', i), memset(str, '$', i)))
		{
			dprintf(1, "\x1b[31mFail\x1b[0m\n");
			return;
		}
		i++;
	}
	dprintf(1, "\x1b[32mOK\x1b[0m\n");
}

void	test_bzero()
{
	char *str=strdup("C M B   D T C");
	char *str2=strdup("C M B   D T C");
	int i = 0;
	
	dprintf(1, "bzero   		");
	while (i < 15)
	{
		ft_bzero(str,i);
		bzero(str2,i);
		if(memcmp(str, str2, i) != 0)
		{
			dprintf(1, "\x1b[31mFail\x1b[0m\n");
			return;
		}
		i++;
	}
	dprintf(1, "\x1b[32mOK\x1b[0m\n");
}

void	test_memcmp()
{
	char str[4][8] = {"", " ", "Ah", "Coucou"};

	int i=0;
	int j;
	int k;
	
	dprintf(1, "memcmp  		");
	while (i < 4)
	{
		j = 0;
		k = 0;
		while (j < 4)
		{
			while (k < 8)
			{
				if(ft_memcmp(str[i],str[j],k) != memcmp(str[i],str[j],k))
				{
					dprintf(1, "\x1b[31mFail\x1b[0m\n");
					return;
				}
				k++;
			}
			j++;
		}
		i++;
	}
	dprintf(1, "\x1b[32mOK\x1b[0m\n");
}

void	test_memcpy()
{
	char	*src = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	char	dest[80];
	char	*ptr;
	char	*ptr2;
	char	*src2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	char	dest2[80];
	bzero(dest,80);
	bzero(dest2,80);
	ptr = (char *) memcpy(dest, src, 26);
	ptr2 = (char *) ft_memcpy(dest2, src2, 26);
	
	dprintf(1, "memcpy  		");
	if (strcmp(ptr, ptr2) != 0)
	{
		dprintf(1, "\x1b[31mFail\x1b[0m\n");
		return;
	}
	dprintf(1, "\x1b[32mOK\x1b[0m\n");
}

void	test_memccpy()
{
	char *srce = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	char dest[80];
	char *ptr;
	char *srce2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	char dest2[80];
	char *ptr2;

	ptr = (char *) memccpy(dest, srce, 'I', strlen(srce));
	ptr2 = (char *) ft_memccpy(dest2, srce2, 'I', strlen(srce2));
	
	dprintf(1, "memccpy  		");
	if (ptr && ptr2)
	{
		*ptr = '\0';
		*ptr2 = '\0';
	}
	if (strcmp(dest,dest2) != 0)
	{
		dprintf(1, "\x1b[31mFail\x1b[0m\n");
		return;
	}
	dprintf(1, "\x1b[32mOK\x1b[0m\n");
}

void	test_memchr()
{
	char ch[30];
	char *ptr;
	char ch2[30];
	char *ptr2;

	dprintf(1, "memchr  		");
	strcpy(ch, "ABCDEFGHIJKLMNOPQRSTUVWXYZ");
	strcpy(ch2, "ABCDEFGHIJKLMNOPQRSTUVWXYZ");
	ptr = (char *) memchr(ch, 'I', strlen(ch));
	ptr2 = (char *) ft_memchr(ch2, 'I', strlen(ch2));
	if (strcmp(ptr, ptr2) != 0)
	{
		dprintf(1, "\x1b[31mFail\x1b[0m\n");
		return;
	}
	dprintf(1, "\x1b[32mOK\x1b[0m\n");
}

void	test_memmove()
{
	char *dest = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	char *str;
	char *str2;
	char *srce = "--------------------------";
	str = strdup(dest);
	str2 = strdup(dest);
	
	dprintf(1, "memmove 		");
	memmove(str, srce, 25);
	ft_memmove(str2, srce, 25);
	if (strcmp(str,str2) != 0)
	{
		dprintf(1, "\x1b[31mFail\x1b[0m\n");
		return;
	}
	dprintf(1, "\x1b[32mOK\x1b[0m\n");
}

void	test_tolower()
{
	int i;
	i = 0;
	
	dprintf(1, "tolower 		");
	while (i < 127)
	{
		if (tolower(i) != ft_tolower(i))
		{
			dprintf(1, "\x1b[31mFail\x1b[0m\n");
			return;
		}
		i++;
	}
	dprintf(1, "\x1b[32mOK\x1b[0m\n");
}

void	test_toupper()
{
	int i;
	i = 0;
	
	dprintf(1, "toupper 		");
	while (i < 127)
	{
		if (toupper(i) != ft_toupper(i))
		{
			dprintf(1, "\x1b[31mFail\x1b[0m\n");
			return;
		}
		i++;
	}
	dprintf(1, "\x1b[32mOK\x1b[0m\n");
}

int main ()
{
	test_memset();
	test_bzero();
	test_memcpy();
	test_memccpy();
	test_memmove();
	test_memchr();
	test_memcmp();
	test_strlen();
	test_strdup();
	test_strcpy();
	test_strncpy();
	test_strcat();
	test_strncat();
	test_strlcat();
	test_strchr();
	test_strrchr();
	test_strstr();
	test_strnstr();
	test_strcmp();
	test_strncmp();
	test_atoi();
	test_isalpha();
	test_isdigit();
	test_isalnum();
	test_isascii();
	test_isprint();
	test_tolower();
	test_toupper();
	return (0);
}
